#!/bin/bash
source $(dirname $0)/common.sh

# ************  Steps ******************
#    Update the target directory test files with proper northbound domain so that integration test can hit the right endpoint
#    Execute the integration test
# *************************************

echo "**** Started Pen test ****"

echo "Northbound domain is: ${r"${apigeeNorthBoundDomain}"}"
echo "Pen Test scripts: ${r"${penTestScript}"}"
echo "Environment testing in: ${r"${penTestEnvironment}"}" 
echo "Output file created in: ${r"${penTestReportOutputDir}"}"
echo "Output file format: ${r"${penTestReportFormat}"}"

echo "*** Runing Pen test ***"

echo "working directory ..."

readyapi-test ${r"${penTestScript}"} -E${r"${penTestEnvironment}"} -F${r"${penTestReportFormat}"} -R"SecurityTest Report" -f${r"${penTestReportOutputDir}"}
if [ $? -ne 0 ]; then
  echo "pen test failed"
  exit 1
fi

echo "**** Pen test complete ****"