#!/bin/bash
source $(dirname $0)/common.sh

# ************  Steps ******************
#    Deploy the bundle
# *************************************

echo "**** Started deployment ****"

echo "Test var is: ${r"${testvar1}"}"
echo "Org is: ${r"${apigeeOrg}"}"
echo "Northbound domain is: ${r"${apigeeNorthBoundDomain}"}"
echo "Environment is: ${r"${apigeeDeployEnvironment}"}"
echo "Username is: ${r"${apigee_user}"}"
echo "Apigee deploy options are: ${r"${apigeeDeployOptions}"}"
echo "Apigee deployment suffix is: ${r"${apigeeDeploymentSuffix}"}" 
echo "Integration test tag is: ${r"${intTestTag}"}"
echo "Token URL is: ${r"${tokenUrl}"}"
echo "Auth type is: ${r"${authType}"}"

echo "Deploying the proxy"
$(mvn_cmd) apigee-enterprise:deploy@deploy-bundle-step -P${r"${apigeeDeployEnvironment}"} -Dorg=${r"${apigeeOrg}"} -Dusername=${r"${apigee_user}"} -Dpassword=${r"${apigee_password}"} -Doptions=${r"${apigeeDeployOptions}"} -DapigeeNorthBoundDomain=${r"${apigeeNorthBoundDomain}"} -Ddeployment.suffix=${r"${apigeeDeploymentSuffix}"} -DtokenUrl=${r"${tokenUrl}"} -DauthType=${r"${authType}"}
if [ $? -ne 0 ]; then
  echo "Unable to deploy the proxy"
  exit 1
fi

echo "**** Deployment complete ****"
