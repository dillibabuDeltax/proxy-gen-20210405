# API proxy for ${openAPI.getInfo().getTitle()}

## Commands

### Install Node dependencies via npm (only need to execute one time)
npm install

### run chai mocha (integration v2) tests (see scripts/local-int script to change env)
npm test

### Troubleshooting - get rid of jp.query error (first run it twice. if error remains, then)
rm -rf ./node_modules
npm install
npm test


## to change test environment
see scripts/local-int-test-v2.sh 

**Shared flows directly used:** sf-response-handler-v1, sf-request-handler-v1, sf-request-error-handler-v1, sf-response-error-handler-v1, sf-logging-v1

**Shared flows indirectly used:** sf-cors-v1, sf-threatprotection-v1, sf-security-v1

**API Version:** 1.0

**Line of businesses covered:** MinuteClinic

**Backend:** DBPL, Wiremock

**Confluence documentation Link:** 

-------------
## Run this API in postman
https://gitw.example.com/api-platform/gateways/example/postman-projects

[![Run in Postman](https://run.pstmn.io/button.svg)](https://app.getpostman.com/run-collection/d3557c2e81847115fe41#?env%5Blocator-api-v1%5D=W3sia2V5IjoieC1hcGkta2V5IiwidmFsdWUiOiJEVU1NWSIsImVuYWJsZWQiOnRydWV9LHsia2V5IjoiaG9zdCIsInZhbHVlIjoiaHR0cHM6Ly9zYW5kYm94LWFwaS5jdnNoZWFsdGguY29tIiwiZW5hYmxlZCI6dHJ1ZX1d)

Please follow this tutorial to import this [Postman Collection](https://www.getpostman.com/docs/collections).


## Pre-requisites
- [ ] NodeJS (includes npm)
- [ ] Java 8 (Oracle JDK 8.0 preferred)
- [ ] Maven

Preferably:
  - [ ] Mac as your development machine
  - [ ] A strong knowledge on Maven is recommended to understand how Maven works and how flexible it is.
  - [ ] Visual Studio Code or any decent IDE
  - [ ] Git client
  - [ ] Access to [Gitlab - API Platform Group](https://gitw.example.com/api-platform/) with a *Developer* role
  - [ ] Access to apigee
    - [ ] Org—> example-non-prod
    - [ ] Env—> sandbox


## Sandbox environment development guide
Before going through the below steps, please read [Apigee Confluence page](https://newcoproduct.atlassian.net/wiki/spaces/apigee/pages/754681341/API+Development+journey) and make sure to understand the basic workflow on how a proxy will be developed and deployed.

- You will have flexibility to deploy the api proxy with a suffix to it so that you can have your own copy of the proxy.
    - Example: curreny-**your-name**-v1
    - This is achieved by using the Maven Environment variable **deployment.suffix**
        - Example: -Ddeployment.suffix=<<your-name>>
- Please refer the maven commands section for more details on what commands to use and for what purpose.

## Folder structure

Please follow the standard folder structure and there is a significance to each directory in the repo.

```
 |apiname-v1
    |-apiproxy/ --> Proxy bundle downloaded from apigee edge after initial development on Sandbox env.
        |-proxies
        |-resources
        |-policies
        |-targets
    |-scripts/ --> Scripts used by CICD Platform. No need to update anything.
        |-build.sh
        |-code-quality.sh
        |-deploy.sh
        |-unit-test.sh
    |-test/ --> Directory for test scripts
        |-integration
           |-test-config.json
           |-features
                |-clinic-locator-api-v1.feature -> feature file where Gherkin scenarios should exist
                |-step-definitions
                    |-apickli-gherkin.js -> out of the box definitions for steps defined in feature file
                    |-init.js -> Initiation script for definitions
                    |-clinic-locator-api-v1.js -> custom definitions for some steps not covered by apickli-gherkin.js
                |-fixtures
        |-security --> ReadyAPI xml aka pen tests
        |-perf
        |-integration-v2 --> contains chai/mocha integration tests
    |-Jenkinsfile --> Drives CICD integration
    |-package.json --> Drives nodejs dependencies for tests
    |-pom.xml --> Maven configurations used for executing various tasks like build, test, deploy, etc.
```

-------------
## Maven commands

### Install Node dependencies
```mvn exec:exec@npm-install```


### Build
1. Step 1
```mvn resources:resources@copy-resources -Ddeployment.suffix=${r"${apigeeDeploymentSuffix}"}```
2. Step 2
```mvn com.google.code.maven-replacer-plugin:replacer:replace@replace-tokens -Ddeployment.suffix=${r"${apigeeDeploymentSuffix}"}```
3. Step 3
```mvn apigee-enterprise:configure@configure-bundle-step -Ddeployment.suffix=${r"${apigeeDeploymentSuffix}"}```

### Code quality
1. Step 1
```mkdir ./target/reports```
2. Step 2
```mvn jshint:lint```
3. Step 3
```mvn exec:exec@apigee-lint```

### Deploy
1. No deployment possible via local environment.
2. Use CI to deploy

### WIP 
mvn verify -Pperformance

### clean, build and test against perf (dbpl)
mvn clean && mvn resources:resources@copy-resources -Ddeployment.suffix=${r"${apigeeDeploymentSuffix}"} && mvn com.google.code.maven-replacer-plugin:replacer:replace@replace-tokens -Ddeployment.suffix=${r"${apigeeDeploymentSuffix}"} && mvn apigee-enterprise:configure@configure-bundle-step -Ddeployment.suffix=${r"${apigeeDeploymentSuffix}"} && mvn resources:resources@copy-apickli-config && mvn com.google.code.maven-replacer-plugin:replacer:replace@replace-apigee-northbound-domain -Dapi.northbound.domain=sit2-api.example.com -Dmock.flag=false && mvn exec:exec@integration-test -Dapi.testtag=@dbpl

### clean, build and test against mock
mvn clean && mvn resources:resources@copy-resources -Ddeployment.suffix=${r"${apigeeDeploymentSuffix}"} && mvn com.google.code.maven-replacer-plugin:replacer:replace@replace-tokens -Ddeployment.suffix=${r"${apigeeDeploymentSuffix}"} && mvn apigee-enterprise:configure@configure-bundle-step -Ddeployment.suffix=${r"${apigeeDeploymentSuffix}"} && mvn resources:resources@copy-apickli-config && mvn com.google.code.maven-replacer-plugin:replacer:replace@replace-apigee-northbound-domain -Dapi.northbound.domain=dev1-api.example.com -Dmock.flag=true && mvn exec:exec@integration-test -Dapi.testtag=@mock

## FAQs

Some frequently asked questions and answers below.

- What environment am I allowed to deploy my proxy?
    - Only dev1
- What are the responsibilities of an API Engineer?
    - Build proxy using OpenAPI spec
      - Generate the proxy using Proxy generator tool
      -  "Code" via Edge UI for proxy-specific requirements (then download as zip and update Git and run pipeline)
      -  Add/update shared flows for code that affects multiple proxies
    - Run code quality scan in local environment to make sure all coding standards are followed. **Note:** Deployment to higher environments is **NOT** permitted if the basic coding standards are NOT met.
    - Write Integration tests hitting mock server (including server failures)
    - Write Integration tests hitting backend (excluding server failures)
    - Run both Integration Tests in local pointing to dev1 environment
    - Configure ReadyAPI (pen test) hitting backend
    - Update the configuration in platform-config-apigee (merge request if needed)
    - Once all the test cases are written and all tests are passing, push the code to Gitlab
- How will CICD kick off?
    - If the specific proxy's repo is enabled with a *post commit hook*, CICD will kick off the Jenkins job automatically.
    - Else, kick off the Jenkins job manually.
