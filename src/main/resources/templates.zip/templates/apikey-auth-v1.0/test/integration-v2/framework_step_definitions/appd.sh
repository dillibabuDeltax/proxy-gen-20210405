echo "in shell script for app D script"


echo "1st parameter is ${r"${1}"}"
echo "2nd parameter is ${r"${2}"}"
echo "3rd parameter is ${r"${3}"}"


tableName=$1
AccountName=$2
apiKey=$3

repoPath=`pwd`
echo "repoPath is: ${r"${repoPath}"}
appdJson=`cat ${r"${repoPath}"}/reports/appd_report.json`
echo "appdJson is ${r"${appdJson}"}"

#: '
curl -X POST "http://appdynamics-dev.corp.example.com:9080/events/publish/${r"${tableName}"}" \
-H"X-Events-API-AccountName:${r"${AccountName}"}" \
-H"X-Events-API-Key:${r"${apiKey}"}" \
-H"Content-type: application/vnd.appd.events+json;v=2" \
-d "${r"${appdJson}"}"
#'